import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Health Check
  app.get("/api/health", (req, res) => {
    const env = process.env;
    const keyCandidates = [
      'GEMINI_API_KEY',
      'API_KEY',
      'VITE_GEMINI_API_KEY',
      'GOOGLE_API_KEY',
      'VITE_API_KEY'
    ];

    let foundKeyName: string | undefined;
    let apiKey: string | undefined;

    for (const candidate of keyCandidates) {
      if (env[candidate]) {
        foundKeyName = candidate;
        apiKey = env[candidate];
        break;
      }
    }

    if (!apiKey) {
      const allKeys = Object.keys(env);
      foundKeyName = allKeys.find(k => 
        keyCandidates.some(c => c.toLowerCase() === k.toLowerCase())
      );
      if (foundKeyName) {
        apiKey = env[foundKeyName];
      }
    }

    // Aggressive search for any key whose value looks like a Google API Key
    if (!apiKey) {
      for (const key in env) {
        const val = env[key];
        if (typeof val === 'string' && val.trim().startsWith('AIza')) {
          apiKey = val;
          foundKeyName = key;
          break;
        }
      }
    }

    res.json({ 
      status: "ok", 
      hasKey: !!apiKey, 
      foundKeyName: foundKeyName || "none",
      keyLength: apiKey ? apiKey.length : 0,
      envKeys: Object.keys(env).filter(k => k.toLowerCase().includes('key') || k.toLowerCase().includes('gemini'))
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
