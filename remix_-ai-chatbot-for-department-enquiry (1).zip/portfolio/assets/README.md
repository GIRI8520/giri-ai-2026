# Assets for SPIHER Portfolio
This folder contains images, icons, and other assets used in the static portfolio version.
