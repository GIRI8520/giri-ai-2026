/* SPIHER Smart Assistant Portfolio Script */
document.addEventListener('DOMContentLoaded', () => {
    console.log("SPIHER Portfolio Loaded Successfully!");

    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', (e) => {
            const text = e.target.innerText;
            console.log(`Button Clicked: ${text}`);
            if (text === 'View Live Demo') {
                alert("Redirecting to Live SPIHER Assistant Demo...");
                // In a real scenario, this would link to the live app URL
                window.location.href = "/";
            } else if (text === 'Source Code') {
                alert("Opening Source Code Repository...");
                // Link to GitHub or similar
            }
        });
    });

    // Smooth Scroll for Navigation
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});
